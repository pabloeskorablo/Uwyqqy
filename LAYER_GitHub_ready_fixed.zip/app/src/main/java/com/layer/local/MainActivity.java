package com.layer.local;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * LAYER local-first control center. Platform widgets only: no remote UI SDK,
 * analytics, fonts, image loaders, web views, or network runtime dependencies.
 */
public final class MainActivity extends Activity {
    private static final int BG = 0xFF090D12;
    private static final int PANEL = 0xFF111821;
    private static final int PANEL_2 = 0xFF18212B;
    private static final int PANEL_3 = 0xFF1D2833;
    private static final int TEXT = 0xFFF5F7F8;
    private static final int MUTED = 0xFF9EABB7;
    private static final int ACCENT = 0xFF8DFFAA;
    private static final int ACCENT_2 = 0xFF5FE38A;
    private static final int WARNING = 0xFFFFD27A;
    private static final int DANGER = 0xFFFF7F8B;
    private static final int LINE = 0xFF28343F;
    private static final int SHADOW = 0x55000000;

    private CheckBox compatibility;
    private CheckBox safe;
    private CheckBox fullSave;
    private TextView status;
    private TextView output;
    private TextView savedPreview;
    private int readerTextSize = 18;
    private int readerLineSpacing = 135;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (status != null) refreshStatus();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(34));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -1));

        addHeader(root);
        addHero(root);
        addQuickActions(root);
        addPrivacy(root);
        addAllowedApps(root);
        addLocalLab(root);
        addVault(root);
        addProtection(root);
        addFooter(root);

        setContentView(scroll);
        refreshStatus();
    }

    private void addHeader(LinearLayout root) {
        LinearLayout header = row();
        TextView logo = txt("L", 24, BG);
        logo.setGravity(Gravity.CENTER);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logo.setBackground(round(ACCENT, 16));
        logo.setElevation(dp(7));
        header.addView(logo, size(dp(48), dp(48)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), dp(1), 0, 0);
        TextView name = txt("LAYER", 26, TEXT);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titles.addView(name);
        TextView sub = txt("локальный слой действий", 13, MUTED);
        titles.addView(sub);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));

        TextView lock = txt("●  LOCAL", 11, ACCENT);
        lock.setGravity(Gravity.CENTER);
        lock.setPadding(dp(10), dp(7), dp(10), dp(7));
        lock.setBackground(round(0x183BFF6B, 50));
        header.addView(lock, new LinearLayout.LayoutParams(-2, -2));
        root.addView(header);

        status = txt("", 12, MUTED);
        status.setPadding(dp(14), dp(11), dp(14), dp(11));
        status.setBackground(round(PANEL, 16));
        root.addView(status, marginTop(dp(13)));
    }

    private void addHero(LinearLayout root) {
        LinearLayout hero = card();
        TextView title = txt("Увидел → нажал L → сделал", 23, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        hero.addView(title);
        TextView body = txt("LAYER не пытается заменить приложения. Он даёт короткий набор локальных действий поверх разрешённого экрана: читать, копировать, находить важное и сохранять только по твоей команде.", 14, MUTED);
        body.setLineSpacing(0, 1.18f);
        hero.addView(body, marginTop(dp(7)));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = row();
        chips.addView(chip("БЕЗ ОБЛАКА"));
        chips.addView(chip("БЕЗ РЕКЛАМЫ"));
        chips.addView(chip("СТРОГИЙ РЕЖИМ"));
        hs.addView(chips, new HorizontalScrollView.LayoutParams(-2, -2));
        hero.addView(hs, marginTop(dp(12)));

        Button setup = primaryButton("Включить / настроить LAYER");
        setup.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        hero.addView(setup, marginTop(dp(14)));
        root.addView(hero, marginTop(dp(16)));
        hero.animate().alpha(1f).setDuration(220).start();
    }

    private void addQuickActions(LinearLayout root) {
        section(root, "Быстрые действия", "Полезное прямо из этого приложения.");
        LinearLayout grid = row();
        View read = actionButton("▤", "Читать", "удобный режим");
        read.setOnClickListener(v -> showReader(outputText(), "Читатель LAYER"));
        grid.addView(read, weight(1));
        View copy = actionButton("□", "Копировать", "явное действие");
        copy.setOnClickListener(v -> copyText(outputText()));
        grid.addView(copy, marginLeftWeight(dp(8), 1));
        View analyze = actionButton("✦", "Разобрать", "локально");
        analyze.setOnClickListener(v -> toast("Вставь текст в локальную лабораторию ниже"));
        grid.addView(analyze, marginLeftWeight(dp(8), 1));
        root.addView(grid);
    }

    private void addPrivacy(LinearLayout root) {
        section(root, "Приватность", "По умолчанию — минимум данных и минимум доверия.");
        LinearLayout box = card();
        box.addView(infoLine("✓", "Сеть", "нет INTERNET permission"));
        box.addView(infoLine("✓", "Облако", "backup отключён"));
        box.addView(infoLine("✓", "Хранение", "только private app storage"));
        box.addView(infoLine("✓", "Чтение", "только после нажатия L"));
        box.addView(infoLine("✓", "Clipboard", "только после явного копирования"));
        root.addView(box);

        safe = check("Сейф-режим", "полностью запретить чтение экрана");
        safe.setChecked(Vault.safeMode(this));
        safe.setOnCheckedChangeListener((v, checked) -> Vault.setSafeMode(this, checked));
        root.addView(checkCard(safe, "Включи перед передачей телефона или когда нужно мгновенно обезвредить LAYER."), marginTop(dp(8)));

        fullSave = check("Полное сохранение", "разрешить хранение полного текста экрана");
        fullSave.setTextColor(WARNING);
        fullSave.setChecked(Vault.fullSaveEnabled(this));
        fullSave.setOnCheckedChangeListener((v, checked) -> {
            Vault.setFullSaveEnabled(this, checked);
            if (checked) toast("Полное сохранение включено — содержимое может быть чувствительным");
        });
        root.addView(checkCard(fullSave, "По умолчанию сохраняется обезличенная версия, а этот режим выключен."), marginTop(dp(8)));

        compatibility = check("Режим совместимости", "разрешать приложения, которых нет в allowlist");
        compatibility.setTextColor(WARNING);
        compatibility.setChecked(Vault.compatibilityMode(this));
        compatibility.setOnCheckedChangeListener((v, checked) -> {
            Vault.setCompatibilityMode(this, checked);
            if (checked) toast("Режим совместимости снижает защиту allowlist");
        });
        root.addView(checkCard(compatibility, "Лучше оставить выключенным. Чувствительные пакеты всё равно блокируются."), marginTop(dp(8)));
    }

    private void addAllowedApps(LinearLayout root) {
        section(root, "Разрешённые приложения", "В строгом режиме каждое приложение разрешается отдельно.");
        List<AppEntry> apps = launcherApps();
        LinearLayout list = card();
        if (apps.isEmpty()) {
            list.addView(txt("Не удалось получить список запускаемых приложений. Можно управлять allowlist через первое нажатие L.", 13, MUTED));
        } else {
            int shown = 0;
            Set<String> allowed = Vault.allowedPackages(this);
            for (AppEntry app : apps) {
                if (SecurityPolicy.isSensitivePackage(this, app.packageName)) continue;
                CheckBox cb = new CheckBox(this);
                cb.setText(app.label + "\n" + app.packageName);
                cb.setTextColor(TEXT);
                cb.setTextSize(13);
                cb.setPadding(0, dp(4), 0, dp(4));
                cb.setChecked(allowed.contains(app.packageName));
                cb.setOnCheckedChangeListener((v, checked) -> {
                    if (checked) Vault.allowPackage(this, app.packageName);
                    else Vault.disallowPackage(this, app.packageName);
                    refreshStatus();
                });
                list.addView(cb);
                shown++;
                if (shown >= 12) break;
            }
            if (shown == 0) list.addView(txt("Нет подходящих приложений. Защищённые пакеты намеренно не показываются.", 13, MUTED));
        }
        root.addView(list);

        Button clear = secondaryButton("Очистить весь allowlist");
        clear.setOnClickListener(v -> {
            Vault.clearAllowedPackages(this);
            toast("Allowlist очищен");
            buildUi();
        });
        root.addView(clear, marginTop(dp(8)));
    }

    private void addLocalLab(LinearLayout root) {
        section(root, "Локальная лаборатория", "Проверяй текст здесь: ничего не отправляется наружу.");
        EditText input = new EditText(this);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setHint("Вставь текст, вакансию, объявление или документ");
        input.setTextSize(16);
        input.setGravity(Gravity.TOP);
        input.setMinLines(6);
        input.setPadding(dp(15), dp(14), dp(15), dp(14));
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setBackground(round(PANEL, 18));
        root.addView(input);

        LinearLayout controls = row();
        Button run = primaryButton("✦  Разобрать локально");
        controls.addView(run, weight(2));
        Button clear = secondaryButton("Очистить");
        controls.addView(clear, marginLeftWeight(dp(8), 1));
        root.addView(controls, marginTop(dp(8)));

        output = txt("Результат появится здесь.", 15, MUTED);
        output.setTextIsSelectable(true);
        output.setGravity(Gravity.TOP);
        output.setLineSpacing(0, 1.18f);
        output.setPadding(dp(16), dp(16), dp(16), dp(16));
        output.setBackground(round(PANEL, 18));
        root.addView(output, marginTop(dp(10)));

        LinearLayout resultActions = row();
        Button reader = secondaryButton("▤  Открыть читатель");
        reader.setOnClickListener(v -> showReader(outputText(), "Результат анализа"));
        resultActions.addView(reader, weight(1));
        Button copy = secondaryButton("□  Скопировать всё");
        copy.setOnClickListener(v -> copyText(outputText()));
        resultActions.addView(copy, marginLeftWeight(dp(8), 1));
        root.addView(resultActions, marginTop(dp(8)));

        run.setOnClickListener(v -> {
            ScreenParser.Parsed p = ScreenParser.parseTextForDemo(input.getText().toString());
            output.setText(formatParsed(p));
            output.setTextColor(TEXT);
            toast("Разбор выполнен локально");
        });
        clear.setOnClickListener(v -> { input.setText(""); output.setText("Результат появится здесь."); output.setTextColor(MUTED); });
    }

    private void addVault(LinearLayout root) {
        section(root, "Локальный сейф", "Зашифрованные записи остаются внутри private app storage.");
        EditText query = new EditText(this);
        query.setTextColor(TEXT);
        query.setHintTextColor(MUTED);
        query.setHint("Поиск сохранённых записей");
        query.setSingleLine(true);
        query.setTextSize(15);
        query.setPadding(dp(14), dp(12), dp(14), dp(12));
        query.setBackground(round(PANEL, 18));
        root.addView(query);

        LinearLayout row = row();
        Button show = secondaryButton("Показать");
        show.setOnClickListener(v -> {
            List<String> items = Vault.searchSaved(this, query.getText().toString());
            StringBuilder b = new StringBuilder();
            if (items.isEmpty()) b.append("Сохранённых записей нет.");
            for (int i = 0; i < items.size(); i++) b.append("#").append(i + 1).append("\n").append(items.get(i)).append("\n\n");
            savedPreview.setText(b.toString());
            savedPreview.setTextColor(TEXT);
        });
        row.addView(show, weight(1));
        Button read = secondaryButton("▤  Читать");
        read.setOnClickListener(v -> showReader(savedPreview == null ? "" : savedPreview.getText().toString(), "Локальный сейф"));
        row.addView(read, marginLeftWeight(dp(8), 1));
        Button wipe = dangerButton("Очистить");
        wipe.setOnClickListener(v -> {
            Vault.clearSaved(this);
            savedPreview.setText("Сейф очищен.");
            savedPreview.setTextColor(MUTED);
            toast("Записи удалены");
        });
        row.addView(wipe, marginLeftWeight(dp(8), 1));
        root.addView(row, marginTop(dp(8)));

        savedPreview = txt("Здесь появятся только найденные тобой локальные записи.", 14, MUTED);
        savedPreview.setTextIsSelectable(true);
        savedPreview.setLineSpacing(0, 1.18f);
        savedPreview.setPadding(dp(16), dp(16), dp(16), dp(16));
        savedPreview.setBackground(round(PANEL, 18));
        root.addView(savedPreview, marginTop(dp(10)));
    }

    private void addProtection(LinearLayout root) {
        section(root, "Жёсткая защита", "Можно явно заблокировать дополнительные package names независимо от режима.");
        EditText protectedInput = new EditText(this);
        protectedInput.setTextColor(TEXT);
        protectedInput.setHintTextColor(MUTED);
        protectedInput.setHint("package.name\nпо одному на строку");
        protectedInput.setTextSize(14);
        protectedInput.setMinLines(3);
        protectedInput.setGravity(Gravity.TOP);
        protectedInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        protectedInput.setText(String.join("\n", Vault.protectedPackages(this)));
        protectedInput.setPadding(dp(14), dp(14), dp(14), dp(14));
        protectedInput.setBackground(round(PANEL, 18));
        root.addView(protectedInput);

        Button save = secondaryButton("Сохранить список блокировки");
        save.setOnClickListener(v -> {
            Set<String> set = new LinkedHashSet<>();
            for (String s : protectedInput.getText().toString().split("\\R")) if (!s.trim().isEmpty()) set.add(s.trim());
            Vault.setProtectedPackages(this, set);
            toast("Список блокировки сохранён локально");
        });
        root.addView(save, marginTop(dp(8)));

        Button wipe = dangerButton("ПАНИЧЕСКИ УНИЧТОЖИТЬ ЛОКАЛЬНЫЕ ДАННЫЕ");
        wipe.setOnClickListener(v -> {
            SecureStore.wipe(this);
            if (savedPreview != null) savedPreview.setText("Сейф уничтожен.");
            if (output != null) output.setText("Локальные данные уничтожены.");
            toast("Ключ и локальное хранилище удалены");
            refreshStatus();
        });
        root.addView(wipe, marginTop(dp(14)));
    }

    private void addFooter(LinearLayout root) {
        TextView note = txt("LAYER не может контролировать root/скомпрометированную ОС, другие privileged accessibility/IME-сервисы и системные журналы Android. Это граница безопасности отдельного APK.", 12, MUTED);
        note.setLineSpacing(0, 1.2f);
        note.setPadding(dp(3), dp(18), dp(3), 0);
        root.addView(note);
    }

    private void showReader(String text, String titleText) {
        if (TextUtils.isEmpty(text) || "Результат появится здесь.".contentEquals(text)) {
            toast("Сначала получи текст для чтения");
            return;
        }

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(18), dp(8), dp(18), 0);
        shell.setBackground(round(PANEL, 26));

        LinearLayout head = row();
        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow = txt("LOCAL READER", 10, ACCENT);
        eyebrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleBox.addView(eyebrow);
        TextView title = txt(titleText, 20, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleBox.addView(title);
        head.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        Button copyTop = secondaryButton("□");
        copyTop.setOnClickListener(v -> copyText(text));
        head.addView(copyTop, new LinearLayout.LayoutParams(dp(48), dp(48)));
        shell.addView(head);

        TextView meta = txt("Выделение пальцем доступно. Никаких фоновых копирований.", 12, MUTED);
        shell.addView(meta, marginTop(dp(5)));

        TextView body = txt(text, readerTextSize, TEXT);
        body.setTextIsSelectable(true);
        body.setGravity(Gravity.TOP);
        body.setLineSpacing(0, readerLineSpacing / 100f);
        body.setPadding(dp(2), dp(14), dp(2), dp(18));
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.addView(body, new ScrollView.LayoutParams(-1, -1));
        shell.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout controls = row();
        Button minus = secondaryButton("A−");
        minus.setOnClickListener(v -> { readerTextSize = Math.max(13, readerTextSize - 1); body.setTextSize(readerTextSize); });
        controls.addView(minus, weight(1));
        Button plus = secondaryButton("A+");
        plus.setOnClickListener(v -> { readerTextSize = Math.min(30, readerTextSize + 1); body.setTextSize(readerTextSize); });
        controls.addView(plus, marginLeftWeight(dp(8), 1));
        Button spacing = secondaryButton("↕");
        spacing.setOnClickListener(v -> { readerLineSpacing += 10; if (readerLineSpacing > 165) readerLineSpacing = 115; body.setLineSpacing(0, readerLineSpacing / 100f); });
        controls.addView(spacing, marginLeftWeight(dp(8), 1));
        Button copy = primaryButton("Скопировать всё");
        copy.setOnClickListener(v -> copyText(body.getText().toString()));
        controls.addView(copy, marginLeftWeight(dp(8), 2));
        shell.addView(controls, marginTop(dp(8)));

        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(shell);
        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(round(BG, 28));
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
            w.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.94f), (int) (getResources().getDisplayMetrics().heightPixels * 0.84f));
        }
        dialog.show();
        if (dialog.getWindow() != null) dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.94f), (int) (getResources().getDisplayMetrics().heightPixels * 0.84f));
    }

    private List<AppEntry> launcherApps() {
        List<AppEntry> result = new ArrayList<>();
        try {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<android.content.pm.ResolveInfo> infos = getPackageManager().queryIntentActivities(intent, 0);
            for (android.content.pm.ResolveInfo info : infos) {
                if (info.activityInfo == null) continue;
                String pkg = info.activityInfo.packageName;
                if (pkg == null || pkg.equals(getPackageName())) continue;
                CharSequence label = info.loadLabel(getPackageManager());
                result.add(new AppEntry(pkg, label == null ? pkg : label.toString()));
            }
            result.sort((a, b) -> a.label.toLowerCase(Locale.ROOT).compareTo(b.label.toLowerCase(Locale.ROOT)));
        } catch (Exception ignored) {}
        return result;
    }

    private String outputText() {
        return output == null ? "" : output.getText().toString();
    }

    private String formatParsed(ScreenParser.Parsed p) {
        StringBuilder b = new StringBuilder();
        b.append("ЛОКАЛЬНАЯ СВОДКА\n\n");
        b.append("Email · ").append(p.emails().size()).append('\n');
        b.append("Телефоны · ").append(p.phones().size()).append('\n');
        b.append("Ссылки · ").append(p.urls().size()).append('\n');
        b.append("Суммы · ").append(p.money().size()).append('\n');
        b.append("Даты · ").append(p.dates().size()).append('\n');
        b.append("Тип · ").append(p.looksLikeJob() ? "похоже на вакансию" : "текст / объявление").append('\n');
        if (!p.emails().isEmpty()) b.append("\nEMAIL\n").append(String.join("\n", p.emails())).append('\n');
        if (!p.phones().isEmpty()) b.append("\nТЕЛЕФОНЫ\n").append(String.join("\n", p.phones())).append('\n');
        if (!p.urls().isEmpty()) b.append("\nССЫЛКИ\n").append(String.join("\n", p.urls())).append('\n');
        if (!p.money().isEmpty()) b.append("\nСУММЫ\n").append(String.join("\n", p.money())).append('\n');
        if (!p.dates().isEmpty()) b.append("\nДАТЫ\n").append(String.join("\n", p.dates())).append('\n');
        if (p.looksLikeJob()) b.append("\nВАКАНСИЯ\n").append(LocalInsights.jobSignals(p.text())).append('\n');
        return b.toString().trim();
    }

    private void copyText(String text) {
        if (TextUtils.isEmpty(text) || "Результат появится здесь.".contentEquals(text)) { toast("Нечего копировать"); return; }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("LAYER", text));
            toast("Скопировано — только после твоего нажатия");
        }
    }

    private void refreshStatus() {
        boolean enabled = false;
        String id = getPackageName() + "/.LayerAccessibilityService";
        try {
            String services = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            enabled = services != null && services.contains(id);
        } catch (Exception ignored) {}
        String mode = Vault.safeMode(this) ? "СЕЙФ-РЕЖИМ" : (Vault.compatibilityMode(this) ? "СОВМЕСТИМОСТЬ" : "ALLOWLIST");
        int count = Vault.allowedPackages(this).size();
        status.setText((enabled ? "● СЕРВИС АКТИВЕН" : "○ СЕРВИС НЕ АКТИВЕН") + "  ·  " + mode + "  ·  " + count + " разрешённых\nДанные LAYER: только на устройстве");
        if (safe != null) safe.setChecked(Vault.safeMode(this));
        if (compatibility != null) compatibility.setChecked(Vault.compatibilityMode(this));
        if (fullSave != null) fullSave.setChecked(Vault.fullSaveEnabled(this));
    }

    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setBackground(round(PANEL, 20));
        l.setElevation(dp(2));
        return l;
    }

    private LinearLayout checkCard(CheckBox c, String note) {
        LinearLayout l = card();
        l.addView(c);
        l.addView(txt(note, 12, MUTED), marginTop(dp(1)));
        return l;
    }

    private TextView infoLine(String mark, String a, String b) {
        TextView t = txt(mark + "  " + a + "  ·  " + b, 13, TEXT);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private void section(LinearLayout root, String title, String sub) {
        TextView h = txt(title, 19, TEXT);
        h.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(h, marginTop(dp(24)));
        root.addView(txt(sub, 12, MUTED), marginBottom(dp(9)));
    }

    private TextView chip(String s) {
        TextView t = txt(s, 10, ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(11), dp(7), dp(11), dp(7));
        t.setBackground(round(0x183BFF6B, 50));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.rightMargin = dp(7);
        t.setLayoutParams(p);
        return t;
    }

    private View actionButton(String icon, String title, String sub) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(8), dp(9), dp(8), dp(8));
        tile.setBackground(round(PANEL_2, 17));
        tile.setClickable(true);
        tile.setFocusable(true);
        tile.setElevation(dp(1));
        TextView i = txt(icon, 19, ACCENT);
        i.setGravity(Gravity.CENTER);
        tile.addView(i);
        TextView t = txt(title, 12, TEXT);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        tile.addView(t, marginTop(dp(2)));
        TextView s = txt(sub, 9, MUTED);
        s.setGravity(Gravity.CENTER);
        tile.addView(s, marginTop(dp(1)));
        return tile;
    }

    private CheckBox check(String title, String sub) {
        CheckBox c = new CheckBox(this);
        c.setText(title + "\n" + sub);
        c.setTextColor(TEXT);
        c.setTextSize(14);
        c.setPadding(0, 0, 0, 0);
        return c;
    }

    private Button primaryButton(String s) {
        Button b = baseButton(s);
        b.setTextColor(BG);
        b.setBackground(round(ACCENT, 17));
        b.setElevation(dp(2));
        return b;
    }

    private Button secondaryButton(String s) {
        Button b = baseButton(s);
        b.setTextColor(TEXT);
        b.setBackground(round(PANEL_2, 17));
        return b;
    }

    private Button dangerButton(String s) {
        Button b = baseButton(s);
        b.setTextColor(DANGER);
        b.setBackground(round(0x221F7C86, 17));
        return b;
    }

    private Button baseButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setMinHeight(dp(50));
        b.setPadding(dp(10), dp(4), dp(10), dp(4));
        b.setStateListAnimator(null);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundTintList(null);
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private LinearLayout.LayoutParams weight(float w) { return new LinearLayout.LayoutParams(0, dp(72), w); }

    private LinearLayout.LayoutParams marginLeftWeight(int left, float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(50), w);
        p.leftMargin = left;
        return p;
    }

    private LinearLayout.LayoutParams size(int w, int h) { return new LinearLayout.LayoutParams(w, h); }

    private LinearLayout.LayoutParams marginTop(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = top;
        return p;
    }

    private LinearLayout.LayoutParams marginBottom(int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = bottom;
        return p;
    }

    private TextView txt(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static final class AppEntry {
        final String packageName;
        final String label;
        AppEntry(String packageName, String label) {
            this.packageName = packageName;
            this.label = label;
        }
    }
}
