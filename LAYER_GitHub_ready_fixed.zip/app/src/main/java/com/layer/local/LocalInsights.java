package com.layer.local;

import java.util.Locale;

/** Deterministic, offline insights. No model, no network, no external process. */
public final class LocalInsights {
    private LocalInsights() {}

    public static String summary(ScreenParser.Parsed p) {
        StringBuilder b=new StringBuilder();
        String text=p.text()==null?"":p.text();
        b.append("Язык (приближённо): ").append(language(text)).append('\n');
        b.append("Символов: ").append(text.length()).append('\n');
        b.append("Email: ").append(p.emails().size()).append("\n");
        b.append("Телефонов: ").append(p.phones().size()).append("\n");
        b.append("Ссылок: ").append(p.urls().size()).append("\n");
        b.append("Сумм: ").append(p.money().size()).append("\n");
        b.append("Дат: ").append(p.dates().size()).append("\n");
        b.append("Тип: ").append(p.looksLikeJob()?"вероятно вакансия/работа":"обычный текст или объявление");
        if(p.looksLikeJob()) b.append("\n\n").append(jobSignals(text));
        return b.toString();
    }

    public static String jobSignals(String text){
        String x=text.toLowerCase(Locale.ROOT);
        StringBuilder b=new StringBuilder();
        b.append("Локальные признаки вакансии:\n");
        if(containsAny(x,"12h","12 hodin","12hod")) b.append("• 12-часовые смены: да\n");
        else if(containsAny(x,"8h","8 hodin","8hod")) b.append("• 8-часовые смены: да\n");
        else b.append("• Продолжительность смены: не определена\n");
        if(containsAny(x,"dvousměnn","třísměnn","směnn","směny")) b.append("• Сменный график: указан\n");
        if(containsAny(x,"hpp","hlavní pracovní poměr")) b.append("• HPP: упомянут\n");
        if(containsAny(x,"dpp","dohoda o provedení práce")) b.append("• DPP: упомянут\n");
        if(containsAny(x,"dpč","dohoda o pracovní činnosti")) b.append("• DPČ: упомянут\n");
        if(containsAny(x,"ubytování","ubytovani")) b.append("• Жильё/общежитие: упомянуто\n");
        if(containsAny(x,"straven","příspěvek na strav","prispevek na strav")) b.append("• Питание/стравенки: упомянуты\n");
        if(containsAny(x,"nástup","nastup","ihned")) b.append("• Выход на работу: указан/возможен быстро\n");
        if(containsAny(x,"řidičský průkaz","ridicsky prukaz","řp","ŘP")) b.append("• Водительские права: требование/упоминание\n");
        if(containsAny(x,"střední","stredni","vzdělání","vzdelani","maturita")) b.append("• Образование: указано\n");
        return trimEnd(b.toString());
    }

    private static boolean containsAny(String text,String... words){
        for(String w:words) if(text.contains(w.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private static String language(String text){
        String x=text.toLowerCase(Locale.ROOT);
        int cs=count(x," a "," práce","pracovn","směn","mzda","požad");
        int ru=count(x," и "," работа","треб","смен","зарплат","руб");
        int uk=count(x," і "," робота","вимог","змін","зарплат","грн");
        int en=count(x," and "," work","job","shift","salary","required");
        int max=Math.max(Math.max(cs,ru),Math.max(uk,en));
        if(max==0) return "неизвестно";
        if(max==cs) return "чешский";
        if(max==ru) return "русский";
        if(max==uk) return "украинский";
        return "английский";
    }

    private static int count(String text,String... needles){
        int n=0; for(String s:needles){int at=0; while((at=text.indexOf(s,at))>=0){n++;at+=s.length();}} return n;
    }

    private static String trimEnd(String s){
        while(s.endsWith("\n")) s=s.substring(0,s.length()-1);
        return s;
    }
}
