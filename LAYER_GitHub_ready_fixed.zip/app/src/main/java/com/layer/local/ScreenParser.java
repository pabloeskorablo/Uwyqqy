package com.layer.local;

import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ScreenParser {
    private static final int MAX_NODES = 1200;
    private static final int MAX_CHARS = 12000;

    private static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
    private static final Pattern PHONE = Pattern.compile("(?<!\\d)(?:\\+?\\d[\\d ()/-]{7,}\\d)(?!\\d)");
    private static final Pattern URL = Pattern.compile("(?i)\\bhttps?://[^\\s<>\\\"']+");
    private static final Pattern MONEY = Pattern.compile("(?i)(?:\\d{1,3}(?:[ .]\\d{3})+|\\d{3,6})\\s*(?:Kč|CZK|EUR|€|USD|\\$)");
    private static final Pattern DATE = Pattern.compile("(?<!\\d)(?:[0-3]?\\d[./-][01]?\\d(?:[./-]\\d{2,4})?|\\d{1,2}\\s+(?:ledna|února|března|dubna|května|června|července|srpna|září|října|listopadu|prosince))(?!\\d)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private ScreenParser() {}

    public static Parsed parse(AccessibilityNodeInfo root) {
        StringBuilder text=new StringBuilder();
        int nodes=0;
        if(root != null){
            ArrayDeque<AccessibilityNodeInfo> q=new ArrayDeque<>(); q.add(root);
            while(!q.isEmpty() && nodes<MAX_NODES && text.length()<MAX_CHARS){
                AccessibilityNodeInfo n=q.removeFirst(); nodes++;
                if(!n.isPassword()){
                    CharSequence t=n.getText();
                    if(t!=null && t.length()>0) append(text,t.toString());
                    CharSequence d=n.getContentDescription();
                    if(d!=null && d.length()>0) append(text,d.toString());
                }
                for(int i=0;i<n.getChildCount() && nodes+q.size()<MAX_NODES;i++){
                    AccessibilityNodeInfo child=n.getChild(i);
                    if(child!=null) q.addLast(child);
                }
                if (n != root) { try{n.recycle();}catch(Exception ignored){} }
            }
        }
        String all=text.toString().trim();
        return new Parsed(all, extract(EMAIL,all), extract(PHONE,all), extract(URL,all), extract(MONEY,all), extract(DATE,all), detectJobs(all));
    }

    public static Parsed parseTextForDemo(String text) {
        String all = text == null ? "" : text.trim();
        return new Parsed(all, extract(EMAIL,all), extract(PHONE,all), extract(URL,all), extract(MONEY,all), extract(DATE,all), detectJobs(all));
    }

    private static void append(StringBuilder sb,String s){
        String clean=s.replace('\n',' ').replace('\r',' ').trim();
        if(clean.isEmpty()) return;
        if(sb.length()>0) sb.append('\n');
        sb.append(clean);
        if(sb.length()>MAX_CHARS) sb.setLength(MAX_CHARS);
    }

    private static List<String> extract(Pattern p,String s){
        Set<String> out=new LinkedHashSet<>(); Matcher m=p.matcher(s);
        while(m.find() && out.size()<20){out.add(m.group().trim());}
        return new ArrayList<>(out);
    }

    private static boolean detectJobs(String s){
        String x=s.toLowerCase(Locale.ROOT);
        int hits=0;
        String[] tokens={"mzda","plat","odměna","pozice","pracovní náplň","požadujeme","nástup","směny","směnn","operátor","výroba","zaměstnání","pracovní doba","Kč".toLowerCase(Locale.ROOT)};
        for(String token:tokens) if(x.contains(token)) hits++;
        return hits>=2;
    }

    public static final class Parsed {
        private final String text;
        private final List<String> emails;
        private final List<String> phones;
        private final List<String> urls;
        private final List<String> money;
        private final List<String> dates;
        private final boolean looksLikeJob;

        public Parsed(String text, List<String> emails, List<String> phones, List<String> urls,
                      List<String> money, List<String> dates, boolean looksLikeJob) {
            this.text = text;
            this.emails = emails;
            this.phones = phones;
            this.urls = urls;
            this.money = money;
            this.dates = dates;
            this.looksLikeJob = looksLikeJob;
        }

        public String text() { return text; }
        public List<String> emails() { return emails; }
        public List<String> phones() { return phones; }
        public List<String> urls() { return urls; }
        public List<String> money() { return money; }
        public List<String> dates() { return dates; }
        public boolean looksLikeJob() { return looksLikeJob; }
    }
}
