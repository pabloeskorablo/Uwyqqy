package com.layer.local;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;

import javax.crypto.AEADBadTagException;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Local encrypted store. It has no network, no export and no external storage path. */
public final class SecureStore {
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String ALIAS = "layer_local_v2";
    private static final String FILE = "vault.enc";
    private static final String TMP = "vault.enc.tmp";
    private static final byte[] MAGIC = new byte[]{'L','Y','R','2'};
    private static final int IV_BYTES = 12;
    private static final int TAG_BITS = 128;
    private static final SecureRandom RNG = new SecureRandom();

    private SecureStore() {}

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        kg.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return kg.generateKey();
    }

    private static File vaultFile(Context context) {
        return new File(context.getFilesDir(), FILE);
    }

    public static synchronized String read(Context context) {
        File f = vaultFile(context);
        if (!f.exists()) return "";
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] all = readAll(in);
            if (all.length < MAGIC.length + IV_BYTES + 1) return "";
            for (int i = 0; i < MAGIC.length; i++) if (all[i] != MAGIC[i]) return "";
            byte[] iv = new byte[IV_BYTES];
            System.arraycopy(all, MAGIC.length, iv, 0, IV_BYTES);
            byte[] cipherText = new byte[all.length - MAGIC.length - IV_BYTES];
            System.arraycopy(all, MAGIC.length + IV_BYTES, cipherText, 0, cipherText.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(TAG_BITS, iv));
            cipher.updateAAD(MAGIC);
            return new String(cipher.doFinal(cipherText), StandardCharsets.UTF_8);
        } catch (AEADBadTagException e) {
            return "";
        } catch (Exception e) {
            return "";
        }
    }

    public static synchronized boolean write(Context context, String plaintext) {
        if (plaintext == null) plaintext = "";
        try {
            byte[] iv = new byte[IV_BYTES];
            RNG.nextBytes(iv);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(TAG_BITS, iv));
            cipher.updateAAD(MAGIC);
            byte[] ct = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));

            File tmp = new File(context.getFilesDir(), TMP);
            try (FileOutputStream out = new FileOutputStream(tmp, false)) {
                out.write(MAGIC);
                out.write(iv);
                out.write(ct);
                out.flush();
                out.getFD().sync();
            }
            File target = vaultFile(context);
            if (target.exists() && !target.delete()) return false;
            if (!tmp.renameTo(target)) {
                tmp.delete();
                return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Deletes the key first, making any remaining ciphertext cryptographically unusable. */
    public static synchronized void wipe(Context context) {
        try {
            KeyStore ks = KeyStore.getInstance(KEYSTORE);
            ks.load(null);
            if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS);
        } catch (Exception ignored) {}
        deleteDirectoryContents(context.getFilesDir());
        deleteDirectoryContents(context.getCacheDir());
        deleteDirectoryContents(context.getCodeCacheDir());
        deleteDirectoryContents(context.getNoBackupFilesDir());
        File externalFiles=context.getExternalFilesDir(null);
        if(externalFiles!=null) deleteDirectoryContents(externalFiles);
        File externalCache=context.getExternalCacheDir();
        if(externalCache!=null) deleteDirectoryContents(externalCache);
    }

    private static void deleteDirectoryContents(File dir) {
        if (dir == null || !dir.exists() || !dir.isDirectory()) return;
        File[] children = dir.listFiles();
        if (children != null) for (File child : children) deleteRecursively(child);
    }

    private static void deleteRecursively(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        try { f.delete(); } catch (Exception ignored) {}
    }

    private static byte[] readAll(FileInputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        return out.toByteArray();
    }
}
