package com.layer.local;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class Vault {
    private static final String KEY_PROTECTED = "protectedPackages";
    private static final String KEY_SAVED = "saved";
    private static final String KEY_ALLOWED = "allowedPackages";
    private static final String KEY_COMPATIBILITY = "compatibilityMode";
    private static final String KEY_SAFE = "safeMode";
    private static final String KEY_FULL_SAVE = "fullSaveEnabled";
    private static final int MAX_SAVED = 50;
    private Vault() {}

    private static JSONObject load(Context c) {
        try {
            String raw = SecureStore.read(c);
            return raw.isEmpty() ? new JSONObject() : new JSONObject(raw);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static void save(Context c, JSONObject o) {
        SecureStore.write(c, o.toString());
    }

    public static synchronized Set<String> allowedPackages(Context c) {
        Set<String> result = new LinkedHashSet<>();
        try {
            JSONArray a = load(c).optJSONArray(KEY_ALLOWED);
            if (a != null) for (int i=0;i<a.length();i++) {
                String s=a.optString(i, "").trim();
                if (!s.isEmpty()) result.add(s);
            }
        } catch (Exception ignored) {}
        return result;
    }

    public static synchronized void clearAllowedPackages(Context c) {
        JSONObject o=load(c);
        try{o.put(KEY_ALLOWED,new JSONArray());}catch(Exception ignored){}
        save(c,o);
    }

    public static synchronized void allowPackage(Context c, String pkg) {
        Set<String> s=allowedPackages(c);
        if(pkg!=null && !pkg.trim().isEmpty()) s.add(pkg.trim());
        JSONObject o=load(c); JSONArray a=new JSONArray();
        for(String p:s) a.put(p);
        try{o.put(KEY_ALLOWED,a);}catch(Exception ignored){}
        save(c,o);
    }

    public static synchronized void disallowPackage(Context c, String pkg) {
        if (pkg == null || pkg.trim().isEmpty()) return;
        Set<String> s=allowedPackages(c);
        s.remove(pkg.trim());
        JSONObject o=load(c); JSONArray a=new JSONArray();
        for(String p:s) a.put(p);
        try{o.put(KEY_ALLOWED,a);}catch(Exception ignored){}
        save(c,o);
    }

    public static synchronized boolean compatibilityMode(Context c) {
        return load(c).optBoolean(KEY_COMPATIBILITY, false);
    }

    public static synchronized void setCompatibilityMode(Context c, boolean value) {
        JSONObject o=load(c);
        try{o.put(KEY_COMPATIBILITY,value);}catch(Exception ignored){}
        save(c,o);
    }

    public static synchronized boolean safeMode(Context c) {
        return load(c).optBoolean(KEY_SAFE, false);
    }

    public static synchronized boolean fullSaveEnabled(Context c) {
        return load(c).optBoolean(KEY_FULL_SAVE, false);
    }

    public static synchronized void setFullSaveEnabled(Context c, boolean value) {
        JSONObject o=load(c);
        try{o.put(KEY_FULL_SAVE,value);}catch(Exception ignored){}
        save(c,o);
    }

    public static synchronized void setSafeMode(Context c, boolean value) {
        JSONObject o=load(c);
        try{o.put(KEY_SAFE,value);}catch(Exception ignored){}
        save(c,o);
    }

    public static synchronized Set<String> protectedPackages(Context c) {
        Set<String> result = new LinkedHashSet<>();
        try {
            JSONArray a = load(c).optJSONArray(KEY_PROTECTED);
            if (a != null) for (int i=0;i<a.length();i++) {
                String s=a.optString(i, "").trim();
                if (!s.isEmpty()) result.add(s);
            }
        } catch (Exception ignored) {}
        return result;
    }

    public static synchronized void setProtectedPackages(Context c, Set<String> packages) {
        JSONObject o=load(c);
        JSONArray a=new JSONArray();
        for (String p:packages) if (p != null && !p.trim().isEmpty()) a.put(p.trim());
        try { o.put(KEY_PROTECTED,a); } catch(Exception ignored) {}
        save(c,o);
    }

    public static synchronized List<String> saved(Context c) {
        List<String> result=new ArrayList<>();
        try {
            JSONArray a=load(c).optJSONArray(KEY_SAVED);
            if(a!=null) for(int i=0;i<a.length();i++) result.add(a.optString(i,""));
        } catch(Exception ignored) {}
        return result;
    }

    public static synchronized void addSaved(Context c, String text) {
        if(text==null) return;
        String clean=text.trim();
        if(clean.isEmpty()) return;
        JSONObject o=load(c);
        JSONArray a=o.optJSONArray(KEY_SAVED);
        if(a==null) a=new JSONArray();
        JSONArray next=new JSONArray();
        next.put(clean);
        for(int i=0;i<a.length() && i<MAX_SAVED-1;i++) {
            String old=a.optString(i,"");
            if(!old.isEmpty() && !old.equals(clean)) next.put(old);
        }
        try{o.put(KEY_SAVED,next);}catch(Exception ignored){}
        save(c,o);
    }

    public static synchronized List<String> searchSaved(Context c, String query) {
        String q=query==null ? "" : query.trim().toLowerCase(java.util.Locale.ROOT);
        List<String> all=saved(c);
        if(q.isEmpty()) return all;
        List<String> result=new ArrayList<>();
        for(String item:all) if(item.toLowerCase(java.util.Locale.ROOT).contains(q)) result.add(item);
        return result;
    }

    public static synchronized void clearSaved(Context c) {
        JSONObject o=load(c);
        try{o.put(KEY_SAVED,new JSONArray());}catch(Exception ignored){}
        save(c,o);
    }
}
