# LAYER has no third-party SDKs.
# Android instantiates these components from the manifest.
-keep public class com.layer.local.LayerAccessibilityService { public <init>(); }
-keep public class com.layer.local.SafeModeTileService { public <init>(); }
-keep public class com.layer.local.MainActivity { public <init>(); }

# Keep constructors/accessors for local value objects used reflectively by tooling.
-keep class com.layer.local.ActionEngine$Action { *; }
-keep class com.layer.local.ScreenParser$Parsed { *; }
