package com.layer.local;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Minimal local overlay. It tracks only package/window changes and parses the
 * accessibility tree strictly after an explicit user tap on the L bubble.
 */
public final class LayerAccessibilityService extends AccessibilityService {
    private static final int BG = 0xFF090D12;
    private static final int PANEL = 0xFF111821;
    private static final int PANEL_2 = 0xFF1A2530;
    private static final int TEXT = 0xFFF5F7F8;
    private static final int MUTED = 0xFF9EABB7;
    private static final int ACCENT = 0xFF8DFFAA;
    private static final int DANGER = 0xFFFF7F8B;

    private WindowManager wm;
    private View bubble;
    private String currentPackage = "";
    private long lastEventAt;
    private WindowManager.LayoutParams bubbleLp;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        applyPrivacyConfiguration();
        showBubble();
    }

    private void applyPrivacyConfiguration() {
        AccessibilityServiceInfo info = getServiceInfo();
        if (info == null) info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 180;
        info.flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence p = event.getPackageName();
        if (p != null && p.length() > 0) currentPackage = p.toString();
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastEventAt < 150) return;
        lastEventAt = now;
    }

    @Override public void onInterrupt() { hideBubble(); currentPackage = ""; }
    @Override public void onDestroy() { hideBubble(); currentPackage = ""; super.onDestroy(); }

    private void showBubble() {
        if (wm == null || bubble != null) return;
        TextView v = new TextView(this);
        v.setText("L");
        v.setTextSize(19);
        v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        v.setTextColor(BG);
        v.setGravity(Gravity.CENTER);
        v.setBackground(round(ACCENT, 50));
        v.setContentDescription("LAYER — открыть локальные действия");
        v.setElevation(dp(8));
        v.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View view, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = bubbleLp.x; startY = bubbleLp.y;
                    moved = false;
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int dx = Math.round(e.getRawX() - downX);
                    int dy = Math.round(e.getRawY() - downY);
                    if (Math.abs(dx) + Math.abs(dy) > dp(8)) moved = true;
                    bubbleLp.x = Math.max(0, startX + dx);
                    bubbleLp.y = startY + dy;
                    try { wm.updateViewLayout(bubble, bubbleLp); } catch (Exception ignored) {}
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (!moved) openPanel();
                    return true;
                }
                return false;
            }
        });
        bubble = v;
        bubbleLp = new WindowManager.LayoutParams(
                dp(50), dp(50), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        bubbleLp.x = dp(10);
        bubbleLp.y = 0;
        try { wm.addView(bubble, bubbleLp); } catch (Exception e) { bubble = null; }
    }

    private void hideBubble() {
        if (wm != null && bubble != null) {
            try { wm.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
        }
    }

    private void openPanel() {
        ContextState state = new ContextState(this, currentPackage);
        if (Vault.safeMode(this)) { showToast("Сейф-режим включён — чтение отключено"); return; }
        if (state.sensitive) { showToast("Чувствительное приложение — чтение заблокировано"); return; }
        if (!state.allowed) { showPermissionPanel(); return; }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        ScreenParser.Parsed parsed = ScreenParser.parse(root);
        if (root != null) try { root.recycle(); } catch (Exception ignored) {}
        showActionPanel(parsed);
    }

    private void showPermissionPanel() {
        LinearLayout panel = shell();
        panel.addView(eyebrow("НУЖНО РАЗРЕШЕНИЕ"));
        panel.addView(title("Это приложение пока не разрешено"), marginTop(dp(5)));
        panel.addView(body("Пакет: " + currentPackage + "\n\nВ строгом режиме LAYER не читал содержимое экрана. Разрешить только этот пакет?"), marginTop(dp(8)));
        Button allow = primaryButton("Разрешить только этот пакет");
        allow.setOnClickListener(v -> {
            Vault.allowPackage(this, currentPackage);
            dismissPanel(panel);
            showToast("Разрешено локально");
        });
        panel.addView(allow, marginTop(dp(12)));
        Button close = secondaryButton("Не разрешать");
        close.setOnClickListener(v -> dismissPanel(panel));
        panel.addView(close, marginTop(dp(8)));
        addOverlay(panel, dp(330), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.CENTER_VERTICAL);
    }

    private void showActionPanel(ScreenParser.Parsed parsed) {
        LinearLayout outer = shell();
        outer.addView(eyebrow("LOCAL ACTIONS"));
        outer.addView(title("Что сделать с этим экраном?"), marginTop(dp(5)));
        outer.addView(body(currentPackage + "\nБез сети · обработка на устройстве"), marginTop(dp(5)));

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        List<ActionEngine.Action> actions = ActionEngine.actions(parsed, Vault.fullSaveEnabled(this));
        if (actions.isEmpty()) {
            list.addView(body("Не найдено доступных локальных действий. На экране может не быть текста, который Android отдаёт accessibility API."));
        }
        for (ActionEngine.Action a : actions) {
            Button action = secondaryButton(labelFor(a));
            action.setOnClickListener(v -> handleAction(a, parsed));
            list.addView(action, marginTop(dp(7)));
        }
        scroll.addView(list, new ScrollView.LayoutParams(-1, -1));
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, dp(390)));

        Button close = secondaryButton("Закрыть");
        close.setOnClickListener(v -> dismissPanel(outer));
        outer.addView(close, marginTop(dp(9)));
        addOverlay(outer, dp(360), dp(520), Gravity.CENTER);
    }

    private String labelFor(ActionEngine.Action a) {
        if ("READ".equals(a.type())) return "▤  Удобно прочитать";
        if ("COPY".equals(a.type())) return "□  Скопировать весь текст";
        if ("SUMMARY".equals(a.type())) return "✦  Короткая сводка";
        if ("JOB".equals(a.type())) return "▣  Разобрать как вакансию";
        if ("SAVE_REDACTED".equals(a.type())) return "▤  Сохранить обезличенно";
        if ("SAVE".equals(a.type())) return "⚠  Сохранить полный текст";
        if ("EMAIL".equals(a.type())) return "@  Найденные email";
        if ("PHONE".equals(a.type())) return "☎  Найденные телефоны";
        if ("URL".equals(a.type())) return "↗  Найденные ссылки";
        if ("MONEY".equals(a.type())) return "₵  Найденные суммы";
        if ("DATE".equals(a.type())) return "◷  Найденные даты";
        return a.title();
    }

    private void handleAction(ActionEngine.Action a, ScreenParser.Parsed p) {
        if ("READ".equals(a.type())) {
            showReaderOverlay(a.payload(), "LAYER · читатель");
            return;
        }
        if ("COPY".equals(a.type())) {
            copyExplicit(a.payload());
            return;
        }
        if ("SAVE".equals(a.type()) || "SAVE_REDACTED".equals(a.type())) {
            Vault.addSaved(this, a.payload());
            showToast("Сохранено только на устройстве");
            return;
        }
        showInfoPanel(a.title(), a.payload());
    }


    private void showReaderOverlay(String text, String titleText) {
        LinearLayout outer = shell();
        outer.addView(eyebrow("LOCAL READER"));
        outer.addView(title(titleText), marginTop(dp(5)));
        TextView hint = body("Выделяй пальцем. A− / A+ меняют размер. Копирование — только после твоего нажатия.");
        hint.setTextColor(MUTED);
        outer.addView(hint, marginTop(dp(5)));

        ScrollView scroll = new ScrollView(this);
        TextView content = body(text);
        content.setTextIsSelectable(true);
        content.setTextSize(17);
        content.setLineSpacing(0, 1.22f);
        content.setPadding(0, dp(12), 0, dp(12));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -1));
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, dp(390)));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        Button minus = secondaryButton("A−");
        minus.setOnClickListener(v -> content.setTextSize(Math.max(13, content.getTextSize() / getResources().getDisplayMetrics().scaledDensity - 1)));
        controls.addView(minus, weight(1));
        Button plus = secondaryButton("A+");
        plus.setOnClickListener(v -> content.setTextSize(Math.min(30, content.getTextSize() / getResources().getDisplayMetrics().scaledDensity + 1)));
        controls.addView(plus, marginLeftWeight(dp(7), 1));
        Button copy = primaryButton("Копировать");
        copy.setOnClickListener(v -> copyExplicit(content.getText().toString()));
        controls.addView(copy, marginLeftWeight(dp(7), 2));
        Button close = secondaryButton("Закрыть");
        close.setOnClickListener(v -> dismissPanel(outer));
        controls.addView(close, marginLeftWeight(dp(7), 2));
        outer.addView(controls, marginTop(dp(8)));
        addOverlay(outer, dp(360), dp(520), Gravity.CENTER);
    }

    private void copyExplicit(String text) {
        if (text == null || text.trim().isEmpty()) { showToast("Нечего копировать"); return; }
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(android.content.ClipData.newPlainText("LAYER", text));
            showToast("Скопировано по явному действию");
        }
    }

    private void showInfoPanel(String titleText, String payload) {
        LinearLayout outer = shell();
        outer.addView(eyebrow("LOCAL RESULT"));
        outer.addView(title(titleText), marginTop(dp(5)));
        TextView text = body(payload);
        text.setTextIsSelectable(true);
        text.setLineSpacing(0, 1.18f);
        outer.addView(text, marginTop(dp(10)));
        LinearLayout actions = row();
        Button copy = primaryButton("Скопировать");
        copy.setOnClickListener(v -> copyText(text.getText().toString()));
        actions.addView(copy, weight(1));
        Button close = secondaryButton("Закрыть");
        close.setOnClickListener(v -> dismissPanel(outer));
        actions.addView(close, marginLeftWeight(dp(8), 1));
        outer.addView(actions, marginTop(dp(10)));
        addOverlay(outer, dp(350), dp(470), Gravity.CENTER);
    }

    private LinearLayout shell() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(17), dp(17), dp(17), dp(17));
        p.setBackground(round(PANEL, 24));
        p.setElevation(dp(12));
        return p;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private TextView eyebrow(String s) { TextView t = body(s); t.setTextSize(10); t.setTextColor(ACCENT); t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); return t; }
    private TextView title(String s) { TextView t = body(s); t.setTextSize(20); t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); return t; }
    private TextView body(String s) { TextView t = new TextView(this); t.setText(s); t.setTextSize(14); t.setTextColor(TEXT); t.setLineSpacing(0, 1.14f); return t; }

    private void addOverlay(View v, int width, int height, int gravity) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(width, height,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = gravity;
        lp.x = dp(10);
        lp.y = 0;
        try { wm.addView(v, lp); } catch (Exception ignored) {}
    }

    private void dismissPanel(View panel) { try { wm.removeView(panel); } catch (Exception ignored) {} }
    private void showToast(String text) { Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show(); }

    private void copyText(String text) {
        if (text == null || text.trim().isEmpty()) { showToast("Нечего копировать"); return; }
        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(android.content.ClipData.newPlainText("LAYER", text));
            showToast("Скопировано по явному действию");
        }
    }

    private Button primaryButton(String s) {
        Button b = baseButton(s); b.setTextColor(BG); b.setBackground(round(ACCENT, 16)); return b;
    }
    private Button secondaryButton(String s) {
        Button b = baseButton(s); b.setTextColor(TEXT); b.setBackground(round(PANEL_2, 16)); return b;
    }
    private Button baseButton(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(13); b.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        b.setMinHeight(dp(48)); b.setPadding(dp(10), 0, dp(10), 0); b.setStateListAnimator(null); b.setGravity(Gravity.CENTER); return b;
    }
    private GradientDrawable round(int color, int radius) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    private LinearLayout.LayoutParams weight(float w) { return new LinearLayout.LayoutParams(0, dp(48), w); }
    private LinearLayout.LayoutParams marginLeftWeight(int left, float w) { LinearLayout.LayoutParams p = weight(w); p.leftMargin = left; return p; }
    private LinearLayout.LayoutParams marginTop(int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = top; return p; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private static final class ContextState {
        final boolean sensitive;
        final boolean allowed;
        ContextState(android.content.Context c, String pkg) {
            sensitive = SecurityPolicy.isSensitivePackage(c, pkg);
            allowed = SecurityPolicy.canReadPackage(c, pkg);
        }
    }
}
