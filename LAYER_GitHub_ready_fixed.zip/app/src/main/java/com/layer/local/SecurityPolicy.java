package com.layer.local;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.provider.Settings;

import java.util.Locale;
import java.util.Set;

/** Centralized, fail-closed access policy. No network or external data path. */
public final class SecurityPolicy {
    private static final String[] SENSITIVE_MARKERS = {
            "bank", "banking", "banka", "bankovní", "wallet", "peněženka", "payments", "payment",
            "paytm", "paypal", "revolut", "wise", "monese", "curve", "authenticator", "otp",
            "password", "heslo", "passkey", "keepass", "bitwarden", "1password", "dashlane", "lastpass",
            "credential", "kredit", "credit", "crypto", "metamask", "seed phrase", "tajenka"
    };

    private SecurityPolicy() {}

    public static boolean isSensitivePackage(Context c, String pkg) {
        if (pkg == null || pkg.trim().isEmpty()) return true;
        if (pkg.equals(c.getPackageName())) return false;
        String x = pkg.toLowerCase(Locale.ROOT);
        for (String marker : SENSITIVE_MARKERS) if (x.contains(marker)) return true;

        // Defense-in-depth: never allow the currently configured input methods.
        try {
            String enabledImes = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_INPUT_METHODS);
            if (enabledImes != null) {
                for (String part : enabledImes.split(":")) {
                    int slash = part.indexOf('/');
                    String imePkg = slash > 0 ? part.substring(0, slash) : part;
                    if (pkg.equals(imePkg)) return true;
                }
            }
        } catch (Exception ignored) {}

        // Also inspect the local app label for obvious sensitive categories.
        try {
            ApplicationInfo ai = c.getPackageManager().getApplicationInfo(pkg, 0);
            CharSequence label = c.getPackageManager().getApplicationLabel(ai);
            String name = label == null ? "" : label.toString().toLowerCase(Locale.ROOT);
            for (String marker : SENSITIVE_MARKERS) if (name.contains(marker)) return true;
        } catch (Exception ignored) {}

        return Vault.protectedPackages(c).contains(pkg);
    }

    public static boolean canReadPackage(Context c, String pkg) {
        if (pkg == null || pkg.trim().isEmpty()) return false;
        if (isSensitivePackage(c, pkg)) return false;
        if (Vault.safeMode(c)) return false;
        if (pkg.equals(c.getPackageName())) return true;
        if (Vault.compatibilityMode(c)) return true;
        Set<String> allowed = Vault.allowedPackages(c);
        return allowed.contains(pkg);
    }
}
