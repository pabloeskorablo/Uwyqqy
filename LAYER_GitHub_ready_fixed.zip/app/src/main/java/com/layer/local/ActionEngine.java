package com.layer.local;

import java.util.ArrayList;
import java.util.List;

/** Local-only action selection. Actions never perform network I/O. */
public final class ActionEngine {
    private ActionEngine() {}

    public static List<Action> actions(ScreenParser.Parsed p, boolean allowFullSave) {
        List<Action> a = new ArrayList<>();
        if (!p.text().isEmpty()) {
            a.add(new Action("READ", "Удобно прочитать", p.text()));
            a.add(new Action("COPY", "Скопировать весь текст", p.text()));
            a.add(new Action("SUMMARY", "Короткая локальная сводка", LocalInsights.summary(p)));
        }
        if (!p.emails().isEmpty()) a.add(new Action("EMAIL", "Найденные email", String.join("\n", p.emails())));
        if (!p.phones().isEmpty()) a.add(new Action("PHONE", "Найденные телефоны", String.join("\n", p.phones())));
        if (!p.urls().isEmpty()) a.add(new Action("URL", "Найденные ссылки", String.join("\n", p.urls())));
        if (!p.money().isEmpty()) a.add(new Action("MONEY", "Найденные суммы", String.join("\n", p.money())));
        if (!p.dates().isEmpty()) a.add(new Action("DATE", "Найденные даты", String.join("\n", p.dates())));
        if (p.looksLikeJob()) a.add(new Action("JOB", "Разобрать как вакансию", buildJobCard(p)));
        if (!p.text().isEmpty()) a.add(new Action("SAVE_REDACTED", "Сохранить обезличенную версию", redact(p.text())));
        if (allowFullSave && !p.text().isEmpty()) a.add(new Action("SAVE", "⚠ Сохранить полный текст", p.text()));
        return a;
    }

    public static List<Action> actions(ScreenParser.Parsed p) { return actions(p, false); }

    private static String redact(String text) {
        String r = text;
        r = r.replaceAll("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}", "[EMAIL]");
        r = r.replaceAll("(?<!\\d)(?:\\+?\\d[\\d ()/-]{7,}\\d)(?!\\d)", "[PHONE]");
        return r;
    }

    private static String buildJobCard(ScreenParser.Parsed p) {
        StringBuilder b = new StringBuilder();
        b.append("Локальный анализ вакансии\n\n");
        if (!p.money().isEmpty()) b.append("Зарплата: ").append(String.join(", ", p.money())).append('\n');
        if (!p.dates().isEmpty()) b.append("Даты: ").append(String.join(", ", p.dates())).append('\n');
        if (!p.phones().isEmpty()) b.append("Телефон: ").append(String.join(", ", p.phones())).append('\n');
        if (!p.emails().isEmpty()) b.append("Email: ").append(String.join(", ", p.emails())).append('\n');
        String lower = p.text().toLowerCase(java.util.Locale.ROOT);
        b.append("Смены: ");
        if (lower.contains("12h") || lower.contains("12 hodin") || lower.contains("12 hodinové")) b.append("встречаются 12-часовые");
        else if (lower.contains("8h") || lower.contains("8 hodin")) b.append("встречаются 8-часовые");
        else if (lower.contains("dvousměnn") || lower.contains("třísměnn") || lower.contains("směnn")) b.append("сменность указана");
        else b.append("не определены");
        return b.toString();
    }

    public static final class Action {
        private final String type;
        private final String title;
        private final String payload;

        public Action(String type, String title, String payload) {
            this.type = type;
            this.title = title;
            this.payload = payload;
        }

        public String type() { return type; }
        public String title() { return title; }
        public String payload() { return payload; }
    }
}
