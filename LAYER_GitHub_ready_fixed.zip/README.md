# LAYER

Нативное Android-приложение local-first: локальный анализ accessibility-экрана, allowlist, сейф-режим, локальный зашифрованный vault и Quick Settings kill switch.

## Бесплатная сборка APK через GitHub Actions

Workflow: `.github/workflows/build-apk.yml`.

Он намеренно **не использует `sdkmanager tools`** — пакет `tools` больше не существует в современном Android SDK. Вместо этого workflow устанавливает только нужные пакеты: `platform-tools`, `platforms;android-35` и `build-tools;35.0.0`. Официальная документация `setup-android` также указывает, что пакет `tools` устарел и больше не предоставляется. 

Toolchain:

- JDK 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- compileSdk 35
- targetSdk 35

Проект в GitHub собирается через установленный Gradle 8.9. Workflow не зависит от `gradle-wrapper.jar`, поэтому отсутствие Wrapper больше не блокирует облачную сборку.

### Как получить APK

1. Загрузи содержимое этого проекта в репозиторий GitHub.
2. Открой **Actions → Build LAYER APK**.
3. Нажми **Run workflow**.
4. После завершения открой артефакт **LAYER-debug-apk** и скачай `app-debug.apk`.

Также сборка автоматически запускается при push в `main`.

## Безопасность

Приложение намеренно не запрашивает `INTERNET` permission. Чтение accessibility-дерева выполняется только после явного нажатия L и после проверки локальной политики доступа. Данные vault хранятся в private app storage и шифруются через Android Keystore.
