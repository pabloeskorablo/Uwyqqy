package com.layer.local;

import android.graphics.drawable.Icon;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** System quick-settings kill switch. It only changes a local boolean. */
public final class SafeModeTileService extends TileService {
    @Override public void onStartListening() { updateTile(); }
    @Override public void onClick() {
        boolean next = !Vault.safeMode(this);
        Vault.setSafeMode(this, next);
        updateTile();
    }
    private void updateTile() {
        Tile tile = getQsTile();
        if (tile == null) return;
        boolean safe = Vault.safeMode(this);
        tile.setState(safe ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setLabel(safe ? "LAYER · Сейф" : "LAYER · Разрешён");
        tile.setContentDescription(safe ? "LAYER: чтение экрана отключено" : "LAYER: чтение экрана разрешено по политике");
        try { tile.setIcon(Icon.createWithResource(this, com.layer.local.R.drawable.ic_launcher)); } catch (Exception ignored) {}
        tile.updateTile();
    }
}
